<?php 
include ("conexion.php");
session_start();

if(isset($_POST['carro'])){
    $perro=$_POST['perrid'];


    $user = $_SESSION['id'];
    
    $sql= "INSERT INTO carrito (id_usuario, id_producto) VALUES ($user, $perro)";
    if (!mysqli_query($enlace,$sql)) {
        die('Error: ' . mysqli_error($enlace));
    }
    
    header("Location: shop.php");

}else{

    $perro=$_POST['deleteid'];


    $sql= "DELETE FROM carrito WHERE id=$perro ";
    if (!mysqli_query($enlace,$sql)) {
        die('Error: ' . mysqli_error($enlace));
    }

    header("Location: cart.php");   
}


// -------------------------------------

?>