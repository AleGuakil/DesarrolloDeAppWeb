<?php

    session_start();

    include ("conexion.php");

    // $product_id = array_column($_SESSION['carrito'],'product_id');

    $result = mysqli_query($enlace,"SELECT * FROM carrito;");


    while($row = mysqli_fetch_array($result)) {

                $totalParcial = (int)$row['precio_producto'] * (int)$row['cantidad'];
                
                $usuario = $row['id_usuario'];
                $producto = $row['id_producto'];
             

                $sql="INSERT INTO historial(id_usuario, id_producto)
                    VALUES ($usuario,$producto);";

                if (!mysqli_query($enlace,$sql)) {
                    die('Error: ' . mysqli_error($enlace));
                }

                

            }
    //Vaciar carrito
    $result3 = mysqli_query($enlace,"DELETE FROM carrito;");


    header("Location: checkout.php");


?>