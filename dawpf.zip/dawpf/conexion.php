

<?php
$enlace = mysqli_connect("localhost", "root", "", "daw_pf");
if (!$enlace) {
    echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
    echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
    echo "<script>alert('$message');</script>";
    exit;
}
echo ".                                                                        .";
echo ".                                        .";

// mysqli_close($enlace);

?>